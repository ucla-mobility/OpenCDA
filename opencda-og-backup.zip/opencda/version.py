"""Specifies the current version number of OpenCDA."""

__version__ = "0.1.3"
