# this folder is mainly about map manager for BEV construction,
# HDMap rasterization, and so on.

