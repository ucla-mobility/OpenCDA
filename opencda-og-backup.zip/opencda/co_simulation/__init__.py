"""
The CARLA-SUMO co-simulation will be released in the contents OpenCDA release v0.2. Current codes are messy.
"""
